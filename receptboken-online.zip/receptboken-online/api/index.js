// api/index.js - Serves index.html with injected environment variables
import { readFileSync } from 'fs';
import { join } from 'path';

export default function handler(req, res) {
  try {
    const filePath = join(process.cwd(), 'public', 'index.html');
    let html = readFileSync(filePath, 'utf8');

    // Inject Supabase credentials from environment variables
    html = html
      .replace('__SUPABASE_URL__', process.env.SUPABASE_URL || '')
      .replace('__SUPABASE_ANON_KEY__', process.env.SUPABASE_ANON_KEY || '');

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache');
    return res.status(200).send(html);
  } catch (e) {
    return res.status(500).send('Server error: ' + e.message);
  }
}
