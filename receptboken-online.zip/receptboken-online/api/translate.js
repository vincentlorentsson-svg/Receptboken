// api/translate.js - Vercel Serverless Function
// Hanterar AI-översättning säkert via server (API-nyckeln är aldrig synlig för användaren)

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { ingr, instructions, langName } = req.body || {};
  if (!ingr || !instructions || !langName) {
    return res.status(400).json({ error: 'Saknar ingr, instructions eller langName' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'API-nyckel saknas på servern' });

  try {
    const prompt = `Översätt följande receptinnehåll till ${langName}. Svara ENDAST med JSON i detta exakta format utan markdown:
{"ingr":["ingrediens1","ingrediens2"],"instructions":"instruktioner här"}

Ingredienser:
${Array.isArray(ingr) ? ingr.join('\n') : ingr}

Instruktioner:
${instructions}`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1024,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || '';
    const clean = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);
    return res.status(200).json(parsed);
  } catch (e) {
    console.error('Translation error:', e);
    return res.status(500).json({ error: 'Översättning misslyckades' });
  }
}
