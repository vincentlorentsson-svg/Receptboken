-- ============================================================
-- RECEPTBOKEN - Supabase Schema
-- Kör detta i Supabase SQL Editor (supabase.com → SQL Editor)
-- ============================================================

-- PROFILER
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  avatar_url text,
  created_at timestamptz default now()
);

-- RECEPT
create table if not exists recipes (
  id text primary key default gen_random_uuid()::text,
  title text not null,
  cats text[] not null default '{}',
  instructions text not null,
  ingr text[] not null default '{}',
  img text,
  servings integer default 4,
  author_id uuid references profiles(id) on delete set null,
  author_name text not null,
  author_avatar text,
  is_seed boolean default false,
  created_at timestamptz default now()
);

-- BETYG
create table if not exists ratings (
  id uuid primary key default gen_random_uuid(),
  recipe_id text references recipes(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  rating integer check (rating >= 1 and rating <= 5),
  created_at timestamptz default now(),
  unique(recipe_id, user_id)
);

-- KOMMENTARER
create table if not exists comments (
  id uuid primary key default gen_random_uuid(),
  recipe_id text references recipes(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  author_name text not null,
  author_avatar text,
  text text not null,
  created_at timestamptz default now()
);

-- FAVORITER
create table if not exists favorites (
  user_id uuid references profiles(id) on delete cascade,
  recipe_id text references recipes(id) on delete cascade,
  primary key (user_id, recipe_id)
);

-- ── ROW LEVEL SECURITY ──
alter table profiles enable row level security;
alter table recipes enable row level security;
alter table ratings enable row level security;
alter table comments enable row level security;
alter table favorites enable row level security;

-- Profiles: alla kan läsa, bara du kan ändra din egen
create policy "Alla kan se profiler" on profiles for select using (true);
create policy "Bara du ändrar din profil" on profiles for update using (auth.uid() = id);
create policy "Skapa profil vid registrering" on profiles for insert with check (auth.uid() = id);

-- Recipes: alla kan läsa, inloggade kan skapa, bara skaparen kan radera
create policy "Alla kan se recept" on recipes for select using (true);
create policy "Inloggade kan skapa recept" on recipes for insert with check (auth.uid() is not null);
create policy "Bara skaparen kan radera" on recipes for delete using (auth.uid() = author_id);
create policy "Bara skaparen kan uppdatera" on recipes for update using (auth.uid() = author_id);

-- Ratings: alla kan läsa, inloggade kan sätta/ändra/ta bort sitt eget
create policy "Alla kan se betyg" on ratings for select using (true);
create policy "Inloggade kan betygsätta" on ratings for insert with check (auth.uid() = user_id);
create policy "Bara ditt eget betyg" on ratings for update using (auth.uid() = user_id);
create policy "Ta bort ditt betyg" on ratings for delete using (auth.uid() = user_id);

-- Comments: alla kan läsa, inloggade kan kommentera, bara egna kan raderas
create policy "Alla kan se kommentarer" on comments for select using (true);
create policy "Inloggade kan kommentera" on comments for insert with check (auth.uid() = user_id);
create policy "Ta bort din kommentar" on comments for delete using (auth.uid() = user_id);

-- Favorites: alla kan se, bara egna
create policy "Alla kan se favoriter" on favorites for select using (true);
create policy "Hantera egna favoriter" on favorites for insert with check (auth.uid() = user_id);
create policy "Ta bort egna favoriter" on favorites for delete using (auth.uid() = user_id);

-- ── STORAGE för profilbilder ──
insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true) on conflict do nothing;
create policy "Alla kan se avatarer" on storage.objects for select using (bucket_id = 'avatars');
create policy "Inloggade kan ladda upp avatar" on storage.objects for insert with check (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "Ta bort egen avatar" on storage.objects for delete using (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);
