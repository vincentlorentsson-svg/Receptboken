# 🍽️ Receptboken — Driftsättningsguide

Följ dessa steg för att göra Receptboken tillgänglig online för alla.
**Allt är gratis. Det tar ca 20 minuter.**

---

## Steg 1 — Skapa konton (gratis)

Skapa konton på dessa tre tjänster om du inte redan har dem:

1. **GitHub** → https://github.com/signup
2. **Supabase** → https://supabase.com (klicka "Start your project")
3. **Vercel** → https://vercel.com/signup (välj "Continue with GitHub")
4. **Anthropic** (för AI-översättning) → https://console.anthropic.com

---

## Steg 2 — Sätt upp Supabase (databas)

### 2a. Skapa ett nytt projekt
1. Logga in på supabase.com
2. Klicka **"New project"**
3. Välj ett namn, t.ex. `receptboken`
4. Välj ett lösenord (spara det!)
5. Välj region: **EU West (Frankfurt)**
6. Klicka **"Create new project"** — vänta ca 1 minut

### 2b. Skapa databasen
1. Klicka på **"SQL Editor"** i vänstermenyn
2. Klicka **"New query"**
3. Öppna filen `supabase_schema.sql` från projektmappen
4. Kopiera ALLT innehåll och klistra in i editorn
5. Klicka **"Run"** (grön knapp)
6. Du ska se: "Success. No rows returned"

### 2c. Hämta dina nycklar
1. Klicka på **"Project Settings"** (kugghjulet) → **"API"**
2. Kopiera och spara dessa två värden:
   - **Project URL** (ser ut som: `https://xxxxx.supabase.co`)
   - **anon public** nyckeln (lång sträng)

---

## Steg 3 — Ladda upp koden till GitHub

### 3a. Skapa ett nytt repository
1. Gå till github.com och logga in
2. Klicka **"+"** uppe till höger → **"New repository"**
3. Namnge det `receptboken`
4. Välj **"Public"**
5. Klicka **"Create repository"**

### 3b. Ladda upp filerna
1. På repository-sidan, klicka **"uploading an existing file"**
2. Dra och släpp ALLA filer från `receptboken-online`-mappen:
   - `vercel.json`
   - `package.json`
   - `supabase_schema.sql`
   - Mappen `api/` (med `index.js` och `translate.js`)
   - Mappen `public/` (med `index.html`)
3. Klicka **"Commit changes"**

---

## Steg 4 — Driftsätt på Vercel (hosting)

### 4a. Importera projektet
1. Gå till vercel.com och logga in med GitHub
2. Klicka **"Add New Project"**
3. Hitta ditt `receptboken` repository och klicka **"Import"**
4. Klicka **"Deploy"** (ändra ingenting)
5. Vänta ca 1 minut — du ser en grön bock när det är klart!

### 4b. Lägg till miljövariabler (hemliga nycklar)
1. Klicka på ditt projekt i Vercel
2. Gå till **"Settings"** → **"Environment Variables"**
3. Lägg till dessa tre variabler (en i taget):

| Name | Value |
|------|-------|
| `SUPABASE_URL` | Din Project URL från steg 2c |
| `SUPABASE_ANON_KEY` | Din anon public-nyckel från steg 2c |
| `ANTHROPIC_API_KEY` | Din API-nyckel från console.anthropic.com |

4. Efter varje variabel, klicka **"Save"**

### 4c. Bygg om sidan
1. Gå till **"Deployments"**-fliken
2. Klicka på de tre prickarna (...) vid den senaste driftsättningen
3. Klicka **"Redeploy"**
4. Vänta 1 minut

---

## Steg 5 — Klart! 🎉

Din Receptboken är nu online på en adress som ser ut som:
`https://receptboken-xxx.vercel.app`

Du kan hitta adressen under "Domains" i Vercel.

### Valfritt: Eget domännamn
1. Köp ett domännamn (t.ex. `receptboken.se`) från t.ex. Loopia eller One.com
2. I Vercel → Settings → Domains → lägg till ditt domännamn
3. Följ instruktionerna för att peka domänen till Vercel

---

## Felsökning

**"Error: invalid API key"** → Kontrollera att du kopierade hela Supabase-nyckeln

**Sidan laddas men inte recepten** → Kontrollera att du körde SQL-scriptet korrekt

**Kan inte logga in** → Supabase kräver e-postbekräftelse. Gå till Supabase → Authentication → Settings → stäng av "Enable email confirmations"

**AI-översättning fungerar inte** → Kontrollera att du lade till `ANTHROPIC_API_KEY` i Vercel

---

## Admin-inloggning

Skapa ett vanligt konto via appen — det finns inget separat admin-konto i online-versionen. Alla som registrerar sig kan lägga till och redigera sina egna recept.
